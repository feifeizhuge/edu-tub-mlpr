""" ps2_implementation.py

PUT YOUR NAME HERE:
<FIRST_NAME><LAST_NAME>


Write the functions
- kmeans
- kmeans_agglo
- agglo_dendro
Write your implementations in the given functions stubs!


(c) Felix Brockherde, TU Berlin, 2013
    Translated to Python from Paul Buenau's Matlab scripts
"""

from __future__ import print_function
from __future__ import division
import numpy as np
from scipy.spatial.distance import cdist
from scipy.cluster.hierarchy import dendrogram
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

def kmeans(X, k, max_iter=100):
    """ Performs k-means clustering

    Input:
    X: (d x n) data matrix with each datapoint in one column
    k: number of clusters
    max_iter: maximum number of iterations

    Output:
    mu: (d x k) matrix with each cluster center in one column
    r: assignment vector
    """

    dim, n = X.shape

    rp = np.random.permutation(range(n))
    mu = X[:, rp[:k]]
    new_mu = np.zeros((dim, k))
    r = np.ones(n)
    new_r = np.zeros(n)

    iteration = 0
    while iteration < max_iter:
        D = cdist(X.T, mu.T)
        new_r = np.argsort(D, 1)[:, 0]

        plt.clf()
        plt.scatter(X[0, :], X[1, :], c=new_r)
        plt.scatter(mu[0, :], mu[1, :], marker='x', c='red', lw=2)
        plt.savefig('kmeans'+str(iteration)+'b.png')

        for i in range(k):
            new_mu[:, i] = np.mean(X[:, new_r == i], 1)

        num_r_changed = np.sum(new_r <> r)
        max_rel_mu_change = np.max(np.sqrt(np.sum((new_mu - mu) ** 2, 0) / 
                np.sum(mu ** 2, 0)))
        loss = np.sum(D[range(n), new_r])

        print('Iteration %d. %d assignments changed. Max relative mu change:'\
                '%.2f, loss: %.2f' %
                (iteration + 1, num_r_changed, max_rel_mu_change, loss))
        
        if num_r_changed == 0:
            break
        
        r = new_r.copy()
        mu = new_mu.copy()
        
        iteration += 1

    return mu, r


def kmeans_agglo(X, r):
    """ Performs agglomerative clustering with k-means criterion

    Input:
    X: (d x n) data matrix with each datapoint in one column
    r: assignment vector

    Output:
    R: (k-1) x n matrix that contains cluster memberships before each step
    kmloss: vector with loss after each step
    mergeidx: (k-1) x 2 matrix that contains merge idx for each step
    """

    def kmeans_crit(X, r):
        """ Computes k-means criterion

        Input: 
        X: (d x n) data matrix with each datapoint in one column
        r: assignment vector

        Output:
        value: scalar for sum of euclidean distances to cluster centers
        """

        dim, n = X.shape
        mu = np.zeros((dim, np.max(r) + 1))
        for i in range(mu.shape[1]):
            cii = np.where(r == i)[0] 
            if len(cii) <> 0:
                mu[:, i] = np.mean(X[:, cii], 1)
            else:
                mu[:, i] = 0.
        return np.sum(np.sqrt(np.sum((X - mu[:, r]) ** 2, 0)))

    dim, n = X.shape
    r = r.copy()
    k = np.max(r) + 1
    R = np.zeros((k-1, n))
    R[0, :] = r

    mergeidx = np.zeros((k-1, 2))

    kmloss = np.zeros(k)
    kmloss[0] = kmeans_crit(X, r)

    # loop over k-2 agglomorative steps
    for i in range(k-2):
        ncl = k - i
        ci = np.sort(np.unique(r))

        # compute change in loss function for each possible merger
        L = np.empty((ncl, ncl))
        L[:] = np.Inf
        for j in range(ncl):
            for l in range(j+1, ncl):
                rt = r.copy()
                rt[rt == ci[j]] = ci[l]

                L[j, l] = kmeans_crit(X, rt)

        # find and do the cheapest merger
        c1, c2 = np.unravel_index(np.argmin(L), L.shape)
        kmloss[i + 1] = L[c1, c2]
        mergeidx[i, :] = [ci[c1], ci[c2]]

        r[r == ci[c1]] = ci[c2].copy()
        R[i + 1, :] = r.copy()

    mergeidx[k - 2, :] = np.unique(r)
    kmloss[k - 1] = kmeans_crit(X, [0]*n)

    return R, kmloss, np.array(mergeidx, dtype=int)


def agglo_dendro(kmloss, mergeidx):
    """ Plots dendrogram for agglomerative clustering

    Input:
    kmloss: vector with loss after each step
    mergeidx: (k-1) x 2 matrix that contains merge idx for each step
    """

    k = len(kmloss)
    y = kmloss - kmloss[0]
    y /= y[-1]

    # this array will hold the sub-clusters of cluster i in row i until it is
    # merged into another sub-cluster
    order = [[i] for i in range(k)]

    # go through all merges
    for i in range(k - 1):
        order[mergeidx[i, 1]][0:0] = order[mergeidx[i, 0]]
        order[mergeidx[i, 0]] = None

    # now all clusters are in row mergeidx[k-1, 1] (since it's the last merge)
    x = np.argsort(order[mergeidx[k - 2, 1]])
    x = np.array(x, dtype=float)
    
    fig = plt.figure(facecolor='white')
    ax = plt.axes(frameon=False)
    ax.set_xticks(x.copy())
    ax.set_xlabel('Cluster index')
    ax.set_ylabel('Increase in criterion function')
    ax.xaxis.tick_top()
    ax.xaxis.set_label_position('top')
    ax.yaxis.tick_left()
    ax.invert_yaxis()

    for i in range(k - 1):
        if i > 0:
            ax.plot([x[mergeidx[i - 1,0]], x[mergeidx[i - 1,1]]], [y[i], y[i]],
                    color='black')
            x[mergeidx[i - 1, 1]] = np.mean(x[mergeidx[i - 1]])
            x[mergeidx[i - 1, 0]] = -1

        for j in range(k):
            if x[j] <> -1:
                ax.plot([x[j], x[j]], [y[i], y[i + 1]], color='#000000')

    ax.plot(x[mergeidx[k - 2]], [y[-1], y[-1]], color='black')
    ax.set_xlim(-.5, k - .5)
    ax.set_ylim(1, 0)
    ymin, ymax = ax.get_yaxis().get_view_interval()
    xmin, xmax = ax.get_xaxis().get_view_interval()
    ax.add_artist(Line2D((xmin, xmin), (ymin, ymax), color='black',
        linewidth=2))
    ax.add_artist(Line2D((xmin, xmax), (ymax, ymax), color='black',
        linewidth=3))
    fig.show()
    return fig


def norm_pdf(X, mu, C):
    """ Computes probability density function for multivariate gaussian

    Input:
    X: (d x n) data matrix with each datapoint in one column
    mu: vector for center
    C: covariance matrix

    Output:
    pdf value for each data point
    """

    if X.ndim < 2:
        X = X[:, np.newaxis]
    dim, n = X.shape
    d = X - np.tile(mu.reshape(-1, 1), (1, n))
    y = ((2. * np.pi) ** (-dim/2.) * np.linalg.det(1e-10 + C) ** (-1./2.) *
            np.exp(-1./2. * np.trace(np.dot(d.T, np.dot(np.linalg.inv(C),
            d)))))
    return y


def em_mog(X, k, max_iter=100, init_kmeans=False, eps=1e-3):
    """ Performs EM Mixture of Gaussians

    Input:
    X: (d x n) data matrix with each datapoint in one column
    k: number of clusters
    max_iter: maximum number of iterations
    init_kmeans: whether kmeans should be used for initialisation
    eps: when log likelihood difference is smaller than eps, terminate loop

    Output:
    pi: 1 x k matrix of priors
    mu: (d x k) matrix with each cluster center in one column
    sigma: list of d x d covariance matrices
    """

    dim, n = X.shape
    mu = np.zeros((dim, k))
    sigma = [None] * k
    mpi = np.zeros(k)

    if init_kmeans:
        mu, r = kmeans(X, k, 100)
        for i in range(k):
            sigma[i] = np.cov(X[:, r==i])
        for i in range(k):
            mpi[i] = np.sum(r==i) / n
    else:
        # random initialization
        mpi = np.random.rand(k)
        mpi /= np.sum(mpi)

        for i in range(k):
            sigma[i] = np.eye(dim, dim)

        rr = np.random.permutation(n)
        mu = X[:, rr[:k]]

    iter = 1
    loglik = 0.

    while iter <= max_iter:
        # E-step: Compute posterior of latent variable (or responsibility) for
        # each datapoint
        r = np.tile(mpi, (n, 1))
        for kk in range(k):
            for nn in range(n):
                r[nn, kk] *= norm_pdf(X[:, nn], mu[:, kk], sigma[kk])
        # As a byproduct, compute log likelihood of the data
        new_loglik = np.sum(np.log(np.sum(r, 0)))

        if np.abs(new_loglik - loglik) < eps:
            print('Reached (local) maximum of log likelihood')
            break
        else:
            print('Iteration %d log likelihood per datapoint = %.5f' % (iter,
                new_loglik / n))
            loglik = new_loglik

        r = r / np.tile(np.sum(r, 1)[:, np.newaxis], (1, k)) 

        # M-step: Estimate parameters
        # Mean
        N = np.zeros(k)
        for kk in range(k):
            N[kk] = np.sum(r[:, kk])
            mpi[kk] = N[kk]/n
            mu[:, kk] = 1./N[kk] * np.dot(X, r[:, kk])
            Xc = X - np.tile(mu[:, kk][:, np.newaxis], (1, n))
            sigma[kk] = 1./N[kk] * np.dot(np.tile(r[:, kk], (dim, 1)) * Xc,
                    Xc.T) + 1e-9 * np.eye(dim)

        #if prog_func is not None:       
        #    if not callable(prog_func):
        #        raise ValueError('prog_func is not callable')
        #    prog_func(X, mu, sigma)

        iter += 1

    return mpi, mu, sigma

def plot_em_solution(X, mu, sigma):
    """ Plots covariance ellipses for EM MoG solution

    Input:
    X: (d x n) data matrix with each datapoint in one column
    mu: (d x k) matrix with each cluster center in one column
    sigma: list of d x d covariance matrices
    """

    fig = plt.figure()
    ax = plt.axes()
    ax.scatter(X[0, :], X[1, :], c='blue', marker='o')
    ax.scatter(mu[0, :], mu[1, :], c='red', marker='x')

    k = len(sigma)

    N = 100
    alpha = np.linspace(0, 2.*np.pi, 100)
    E = np.vstack((np.cos(alpha), np.sin(alpha)))
    
    for i in range(k):
        w, v = np.linalg.eigh(sigma[i])

        XY = (np.dot(np.dot(v, np.diag(np.sqrt(w))), E) +
                np.tile(mu[:, i][:, np.newaxis], (1, N)))
        ax.plot(XY[0, :], XY[1, :], color='red', linestyle='-')
    fig.show()
    raw_input('Press enter to continue...')
    plt.close()
