""" ps3_application.py

PUT YOUR NAME HERE:
<FIRST_NAME><LAST_NAME>


Write the functions
- roc_curve
- krr_app

Write your code in the given functions stubs!


(c) Daniel Bartz, TU Berlin, 2013
"""
import numpy as np
import pylab as pl
import random
# import matplotlib as pl
# from mpl_toolkits.mplot3d import Axes3D
# from matplotlib.lines import Line2D
from scipy.stats import norm
import os
import sys
import pickle


import ps3_implementation as imp
imp = reload(imp)


def roc_curve(n):
    ''' your header here!
    '''


def roc_fun(y_true, y_pred):
    ''' your header here!
    '''

    
def krr_app(reg=False):
    ''' your header here!
    '''

