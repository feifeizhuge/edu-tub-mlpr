""" sheet1_implementation.py

PUT YOUR NAME HERE:
<FIRST_NAME><LAST_NAME>


Write the functions
- usps
- outliers
- lle
Write your implementations in the given functions stubs!


(c) Daniel Bartz, TU Berlin, 2013
"""
import numpy as np
import pylab as pl
import random

import ps1_implementation as imp
imp = reload(imp)


def usps():
    ''' performs the usps analysis for assignment 4'''

                
        
def outliers_calc():
    ''' outlier analysis for assignment 5'''
    
    # np.savez_compressed('outliers', var1=var1, var2=var2, ...)

            
def outliers_disp():
    ''' display the boxplots'''
    results = np.load('outliers.npz')
    
            
            

def lle_visualize(dataset='flatroll'):
    ''' visualization of LLE for assignment 6'''
    
    

def lle_noise():
    ''' LLE under noise for assignment 7'''    


